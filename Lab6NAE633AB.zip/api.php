<?php
// Setăm header-ul pentru a spune browserului că răspundem cu JSON
header('Content-Type: application/json');
// Permitem accesul (CORS) - util pentru dezvoltare
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");

require_once 'db.php'; 

// Verificăm metoda cererii (GET sau POST)
$method = $_SERVER['REQUEST_METHOD'];

// ---------------------------------------------------------
// 1. GET - Trimitem lista de studenți
// ---------------------------------------------------------
if ($method === 'GET') {
    try {
        // În PDO nu folosim query() simplu la fel ca în mysqli, 
        // dar pentru SELECT simplu e similar, însă fetch-ul e diferit.
        $stmt = $pdo->query("SELECT * FROM studenti ORDER BY id DESC");
        
        // fetchAll() ia toate rândurile deodată într-un array asociativ
        $studenti = $stmt->fetchAll();
        
        echo json_encode($studenti);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(["error" => "Eroare la citire: " . $e->getMessage()]);
    }
}

// ---------------------------------------------------------
// 2. POST - Adăugăm un student nou
// ---------------------------------------------------------
if ($method === 'POST') {
    try {
        // Citim JSON-ul trimis de JavaScript
        $input = file_get_contents("php://input");
        $data = json_decode($input, true);

        // Validare simplă
        if (!isset($data['nume']) || !isset($data['an']) || !isset($data['media'])) {
            echo json_encode(["status" => "error", "message" => "Date incomplete"]);
            exit;
        }

        // --- AICI ESTE SCHIMBAREA MAJORĂ PENTRU PDO ---
        // Folosim "Named Placeholders" (:nume, :an, :media)
        $sql = "INSERT INTO studenti (nume, an, media) VALUES (:nume, :an, :media)";
        
        $stmt = $pdo->prepare($sql);
        
        $succes = $stmt->execute([
            ':nume'  => $data['nume'],
            ':an'    => $data['an'],
            ':media' => $data['media']
        ]);

        if ($succes) {
            echo json_encode(["status" => "success", "message" => "Student adăugat!"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Nu s-a putut adăuga studentul."]);
        }

    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Eroare SQL: " . $e->getMessage()]);
    }
}
?>